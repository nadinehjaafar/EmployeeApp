const mongoose = require('mongoose')
const employeeSchema = mongoose.Schema({
    name: {
        type: String,
        required: [true, "Please enter the employee name."]
    },
    department: {
        type: String,
        required: [true, "Please enter the employee department."]
    },
    title: {
        type: String,
        required: [true, "Please enter the employee title."]
    },
    location: {
        type: String,
        required: [true, "Please enter the employee location."]
    },
    picture: {
        type: String,
        required: false
    },
    DOB: {
        type: Date,
        required: [true, "Please enter the employee DOB."]
    }
})

const Employee = mongoose.model('Employee', employeeSchema);

module.exports = Employee;

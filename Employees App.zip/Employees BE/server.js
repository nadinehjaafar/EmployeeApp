const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors');
const Employee = require('./models/employeeModel')
const multer = require('multer');
const app = express()

const port = 8080;
app.use(express.json())

app.use(cors());

const upload = multer({
    limits: {
        fileSize: 100 * 1024 * 1024,
    }
});

app.get('/AllEmployees', async (req, res) => {
    try {
        const employees = await Employee.find({});
        res.status(200).json(employees);
    } catch (error) {
        res.status(500).json({message: error.message})
    }
})

app.get('/employees', async (req, res) => {
    try {
        const { page = 1, limit = 3 } = req.query;
        const skip = (page - 1) * limit;

        const totalEmployees = await Employee.countDocuments({});
        const totalPages = Math.ceil(totalEmployees / limit);

        const employees = await Employee.find({}).skip(skip).limit(Number(limit));

        res.status(200).json({ employees, totalPages });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});


app.get('/employee/:id', async (req, res) => {
    try {
        const {id} = req.params;
        const employee = await Employee.findById(id);
        res.status(200).json(employee);
    } catch (error) {
        res.status(500).json({message: error.message})
    }
})

app.post('/employee', upload.single('picture'), async (req, res) => {
    try {
        const {
            name,
            department,
            title,
            location,
            DOB
        } = req.body;

        const picture = req.file ? req.file.buffer.toString('base64') : null;

        const employee = await Employee.create({
            name,
            department,
            title,
            location,
            DOB,
            picture
        });

        res.status(200).json(employee);
    } catch (error) {
        console.log(error.message);
        res.status(500).json({message: error.message});
    }
});

app.put('/employee/:id', upload.single('picture'), async (req, res) => {
    try {
        const {id} = req.params;
        const {
            name,
            department,
            title,
            location,
            DOB
        } = req.body;

        const picture = req.file ? req.file.buffer.toString('base64') : null;

        const updatedData = {
            name,
            department,
            title,
            location,
            DOB,
            picture
        };

        const employee = await Employee.findByIdAndUpdate(id, updatedData, {new: true});

        if (! employee) {
            return res.status(404).json({message: `Wrong ID!`});
        }

        res.status(200).json(employee);
    } catch (error) {
        res.status(500).json({message: error.message});
    }
});

app.delete('/employee/:id', async (req, res) => {
    try {
        const {id} = req.params;
        const employee = await Employee.findByIdAndDelete(id);
        if (! employee) {
            return res.status(404).json({message: `wrong ID !`});
        }
        res.status(200).json(employee);
    } catch (error) {
        res.status(500).json({message: error.message})
    }
})

mongoose.connect('mongodb+srv://admin:admin@empapp.u4lunpd.mongodb.net/emp?retryWrites=true&w=majority').then(() => {
    app.listen(port, () => {
        console.log(`Employee app running!`)
    });
    console.log('Connected to MongoDB!')
}).catch(() => {
    console.log(error)
})

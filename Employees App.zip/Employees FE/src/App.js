import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Navbar from "./layout/Navbar";
import Home from "./pages/Home";
import AddEmployee from "./employees/AddEmployee";
import EditEmployee from "./employees/EditEmployee";
import ViewEmployee from "./employees/ViewEmployee";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

function App() {
  return (
    <div className="App">
      <Router>
        <Content />
      </Router>
    </div>
  );
}

function Content() {
  return (
    <>
      <Navbar />
      <div className="content">
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route exact path="/AddEmployee" element={<AddEmployee />} />
          <Route exact path="/EditEmployee/:id" element={<EditEmployee />} />
          <Route exact path="/ViewEmployee/:id" element={<ViewEmployee />} />
        </Routes>
      </div>
    </>
  );
}

export default App;
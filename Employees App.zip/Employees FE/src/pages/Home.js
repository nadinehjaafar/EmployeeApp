import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";

export default function Home() {
  const [employees, setEmployees] = useState([]);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("name");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [allEmployees, setAllEmployees] = useState([]);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleFilterChange = (e) => {
    setFilterType(e.target.value);
  };

  useEffect(() => {
    loadData();
  }, [currentPage]);

  const filteredEmployees = allEmployees?.filter((employee) =>
    employee[filterType].toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  const loadData = async () => {
    try {
      const response = await axios.get(`http://localhost:8080/employees`, {
        params: { page: currentPage, limit: 3 },
      });
      if (currentPage === 1) {
        setAllEmployees(response.data.employees);
      } else {
        setAllEmployees((prevEmployees) => [...prevEmployees, ...response.data.employees]);
      }

      setTotalPages(response.data.totalPages);
    } catch (error) {
      setErrorMessage("Failed to load data. Please try again later.");
      setShowErrorModal(true);
    }
  };

  const deleteData = async (id) => {
    await axios.delete(`http://localhost:8080/employee/${id}`);
    loadData();
  };

  const handleLoadMore = () => {
    setCurrentPage((prevPage) => prevPage + 1);
  };

  const handleCloseErrorModal = () => {
    setShowErrorModal(false);
  };

  return (
    <div className="container">
      <div className="py-4">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h2>Employees</h2>
          <Link className="btn btn-outline-light ms-2" to="/AddEmployee">
            <button className="btn btn-primary">Add Employee</button>
          </Link>
        </div>
        <div className="mb-3">
          <div className="d-flex align-items-center mb-2">
            <span className="me-2">Filter by:</span>
            <select
              className="form-select me-4"
              onChange={handleFilterChange}
              value={filterType}
              style={{ width: "150px" }}
            >
              <option value="name">Name</option>
              <option value="department">Department</option>
              <option value="title">Title</option>
              <option value="location">Location</option>
            </select>
          </div>
          <input
            type="text"
            className="form-control"
            placeholder={`Search employees by ${filterType}...(please load all employees before searching)...`}
            value={searchQuery}
            onChange={handleSearchChange}
          />
        </div>

        <table className="table border shadow">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Department</th>
              <th scope="col">Title</th>
              <th scope="col">Location</th>
              <th scope="col">DOB</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredEmployees.map((employee, index) => (
              <tr key={employee._id}>
                <td>{employee._id}</td>
                <td>{employee.name}</td>
                <td>{employee.department}</td>
                <td>{employee.title}</td>
                <td>{employee.location}</td>
                <td>{employee.DOB.split("T")[0]}</td>
                <td>
                  <Link
                    className="btn btn-outline-primary mx-2"
                    to={`/ViewEmployee/${employee._id}`}
                  >
                    View
                  </Link>
                  <Link
                    className="btn btn-outline-primary mx-2"
                    to={`/EditEmployee/${employee._id}`}
                  >
                    Edit
                  </Link>
                  <button
                    className="btn btn-danger mx-2"
                    onClick={() => deleteData(employee._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {currentPage < totalPages && (
          <button className="btn btn-primary" onClick={handleLoadMore}>
            Load more
          </button>
        )}
      </div>
      <Modal
        show={showErrorModal}
        onHide={handleCloseErrorModal}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Error</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p style={{ color: "red" }}>{errorMessage}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button onClick={handleCloseErrorModal}>Close</Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}
export const employee = {
    name: "",
    department: "",
    title: "",
    location: "",
    picture: "",
    DOB: ""
};

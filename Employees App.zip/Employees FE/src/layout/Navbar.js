import React, {useEffect} from "react";
import {Link} from "react-router-dom";

export default function Navbar() { 
    return (
        <div className="sidebar">
            <ul>
                <li>
                    <Link to={`/`}
                        style={
                            {
                                color: "inherit",
                                textDecoration: "none"
                            }
                    }>
                        Employees
                    </Link>
                </li>
            </ul>
        </div>
    );
}

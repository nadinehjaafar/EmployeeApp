import axios from "axios";
import React, {useEffect, useState} from "react";
import {Link, useNavigate, useParams} from "react-router-dom";
import {employee} from "../model/employee_constants";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";

export default function EditEmployee() {
    let navigate = useNavigate();
    const [showErrorModal, setShowErrorModal] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");
    const {id} = useParams();
    const [selectedFile, setSelectedFile] = useState(null);
    const [employeeData, setEmployeeData] = useState({
        ...employee
    });

    const onInputChange = (e) => {
        setEmployeeData({
            ...employeeData,
            [e.target.name]: e.target.value
        });
    };

    const onFileInputChange = (e) => {
        const file = e.target.files[0];
        setSelectedFile(file);

        const reader = new FileReader();
        reader.readAsDataURL(file);

        reader.onloadend = () => {
            setEmployeeData({
                ...employeeData,
                picture: reader.result
            });
        };
    };

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const result = await axios.get(`http://localhost:8080/employee/${id}`);
            setEmployeeData(result.data);
        } catch (error) {
            setErrorMessage("Failed to load data. Please try again later.");
            setShowErrorModal(true);
        }
    };

    const onSubmitEmployee = async (e) => {
        try {
            e.preventDefault();

            const formData = new FormData();
            formData.append('name', employeeData.name);
            formData.append('department', employeeData.department);
            formData.append('title', employeeData.title);
            formData.append('location', employeeData.location);
            formData.append('DOB', employeeData.DOB);
            formData.append('picture', selectedFile);

            await axios.put(`http://localhost:8080/employee/${id}`, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });

            navigate("/");
        } catch (error) {
            setErrorMessage("Failed to add data. Please try again later.");
            setShowErrorModal(true);
        }
    };

    const handleCloseErrorModal = () => {
        setShowErrorModal(false);
    };

    return (
        <div className="container">
            <div className="row">
                <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
                    <h2 className="text-center m-4">Edit Employee</h2>
                    <form onSubmitEmployee={
                        (e) => onSubmitEmployee(e)
                    }>


                        <div className="mb-3">
                            <label htmlFor="Name" className="form-label">
                                Employee name:
                            </label>
                            <input type={"text"}
                                className="form-control"
                                placeholder="Enter employee name"
                                name="name"
                                value={
                                    employeeData.name
                                }
                                onChange={
                                    (e) => onInputChange(e)
                                }/>
                        </div>

                        <div className="mb-3">
                            <label htmlFor="Department" className="form-label">
                                Employee department:
                            </label>
                            <input type={"text"}
                                className="form-control"
                                placeholder="Enter employee department"
                                name="department"
                                value={
                                    employeeData.department
                                }
                                onChange={
                                    (e) => onInputChange(e)
                                }/>
                        </div>

                        <div className="mb-3">
                            <label htmlFor="Title" className="form-label">
                                Employee title:
                            </label>
                            <input type={"text"}
                                className="form-control"
                                placeholder="Enter employee title"
                                name="title"
                                value={
                                    employeeData.title
                                }
                                onChange={
                                    (e) => onInputChange(e)
                                }/>
                        </div>

                        <div className="mb-3">
                            <label htmlFor="Location" className="form-label">
                                Employee location:
                            </label>
                            <input type={"text"}
                                className="form-control"
                                placeholder="Enter employee location"
                                name="location"
                                value={
                                    employeeData.location
                                }
                                onChange={
                                    (e) => onInputChange(e)
                                }/>
                        </div>
                        <div className="mb-3">
                            <label htmlFor="DOB" className="form-label">
                                Employee DOB:
                            </label>
                            <input type={"date"}
                                className="form-control"
                                placeholder="Enter DOB"
                                name="DOB"
                                value={
                                    employeeData.DOB.split('T')[0]
                                }
                                onChange={
                                    (e) => onInputChange(e)
                                }
                                disabled/>

                        </div>
                        <div className="mb-3">
                            <label htmlFor="Picture" className="form-label">
                                Employee picture:
                            </label>
                            <input type="file"
                                className="form-control"
                                name="picture"
                                onChange={
                                    (e) => onFileInputChange(e)
                                }/>
                        </div>
                    </form>
                    <div className="text-center">
                        <button type="submit" className="btn btn-outline-primary "
                            onClick={onSubmitEmployee}>
                            Save changes
                        </button>
                        <Link className="btn btn-outline-danger mx-2" to="/">
                            Cancel
                        </Link>
                    </div>
                </div>


            </div>
            <Modal show={showErrorModal}
                onHide={handleCloseErrorModal}
                centered>
                <Modal.Header closeButton>
                    <Modal.Title>Error</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <p style={
                        {color: "red"}
                    }>
                        {errorMessage}</p>
                </Modal.Body>
                <Modal.Footer>
                    <Button onClick={handleCloseErrorModal}>Close</Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
}

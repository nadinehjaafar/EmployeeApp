import React, {useEffect, useState} from "react";
import axios from "axios";
import {Link, useParams} from "react-router-dom";
import {employee} from "../model/employee_constants";

export default function ViewEmployee() {
    const [employeeData, setEmployeeData] = useState({
        ...employee
    });
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    const {id} = useParams();

    useEffect(() => {
        loadEmployee();
    }, []);

    const loadEmployee = async () => {
        try {
            const result = await axios.get(`http://localhost:8080/employee/${id}`);
            setEmployeeData(result.data);
            setLoading(false);
        } catch (error) {
            setError("Failed to load data. Please try again later.");
            setLoading(false);
        }
    };

    return (
        <div className="container">
            <div className="row justify-content-center">
                <div className="col-md-8 border rounded p-4 mt-4 shadow">
                    <h2 className="text-center mb-4">Employee Details</h2>
                    {
                    loading ? (
                        <p className="text-center">Loading employee data...</p>
                    ) : error ? (
                        <p className="text-center"
                            style={
                                {color: "red"}
                        }>
                            {error} </p>
                    ) : (
                        <div className="card">
                            <div className="card-header">
                                Details of employee (ID: {
                                employeeData._id
                            })
                            </div>
                            <ul className="list-group list-group-flush">
                                <li className="list-group-item">
                                    <b style={
                                        {marginRight: "8px"}
                                    }>Name:
                                    </b>
                                    {
                                    employeeData.name
                                } </li>
                                <li className="list-group-item">
                                    <b style={
                                        {marginRight: "8px"}
                                    }>Department:
                                    </b>
                                    {
                                    employeeData.department
                                } </li>
                                <li className="list-group-item">
                                    <b style={
                                        {marginRight: "8px"}
                                    }>Title:
                                    </b>
                                    {
                                    employeeData.title
                                } </li>
                                <li className="list-group-item">
                                    <b style={
                                        {marginRight: "8px"}
                                    }>Location:
                                    </b>
                                    {
                                    employeeData.location
                                } </li>
                                <li className="list-group-item">
                                    <b style={
                                        {marginRight: "8px"}
                                    }>DOB:</b>
                                    {
                                    employeeData.DOB.split("T")[0]
                                } </li>
                            </ul>
                            {
                            employeeData.picture && (
                                <div className="card-footer"
                                    style={
                                        {
                                            marginBottom: "20px",
                                            background: "white"
                                        }
                                }>
                                    <b>Picture:
                                    </b>
                                    <br></br>
                                    <img src={
                                            `data:image/jpeg;base64,${
                                                employeeData.picture
                                            }`
                                        }
                                        alt="Employee"
                                        className="img-fluid mt-2"
                                        style={
                                            {
                                                maxWidth: "300px",
                                                maxHeight: "300px"
                                            }
                                        }/>
                                </div>
                            )
                        } </div>
                    )
                }
                    <div className="text-center mt-4">
                        <Link className="btn btn-primary"
                            to={"/"}>
                            Back to Home page
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
}

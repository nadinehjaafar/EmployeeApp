import axios from "axios";
import React, {useState} from "react";
import {Link, useNavigate} from "react-router-dom";
import {employee} from "../model/employee_constants";

import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";

export default function AddEmployee() { // redux

    let navigate = useNavigate();
    const [showErrorModal, setShowErrorModal] = useState(false); // State for showing/hiding the error modal
    const [errorMessage, setErrorMessage] = useState(""); // State for storing the error message

    const [employeeData, setEmployeeData] = useState({
        ...employee
    });

    const [selectedFile, setSelectedFile] = useState(null);

    const onInputChange = (e) => {
        setEmployeeData({
            ...employeeData,
            [e.target.name]: e.target.value
        });
    };

    const onFileInputChange = (e) => {
        const file = e.target.files[0];
        setSelectedFile(file); // Store the selected file in state

        const reader = new FileReader();
        reader.readAsDataURL(file);

        reader.onloadend = () => {
            setEmployeeData({
                ...employeeData,
                picture: reader.result
            });
        };
    };

    const onSubmit = async (e) => {
        try {
            e.preventDefault();

            // Create a new FormData object to send data along with the image file
            const formData = new FormData();
            formData.append('name', employeeData.name);
            formData.append('department', employeeData.department);
            formData.append('title', employeeData.title);
            formData.append('location', employeeData.location);
            formData.append('DOB', employeeData.DOB);
            formData.append('picture', selectedFile); // Append the selected file to the FormData

            await axios.post("http://localhost:8080/employee", formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });

            navigate("/");
        } catch (error) {
            setErrorMessage("Failed to add data. Please try again later.");
            setShowErrorModal(true);
        }
    };

    const handleCloseErrorModal = () => {
        setShowErrorModal(false); // Hide the error modal
    };

    return (
        <div className="container">
            <div className="row">
                <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
                    <h2 className="text-center m-4">Add Employee</h2>
                    <form onSubmit={
                        (e) => onSubmit(e)
                    }>
                        <div className="mb-3">
                            <label htmlFor="Name" className="form-label">
                                Employee name:
                            </label>
                            <input type={"text"}
                                className="form-control"
                                placeholder="Enter employee name"
                                name="name"
                                value={
                                    employeeData.name
                                }
                                onChange={
                                    (e) => onInputChange(e)
                                }/>
                        </div>

                        <div className="mb-3">
                            <label htmlFor="Department" className="form-label">
                                Employee department:
                            </label>
                            <input type={"text"}
                                className="form-control"
                                placeholder="Enter employee department"
                                name="department"
                                value={
                                    employeeData.department
                                }
                                onChange={
                                    (e) => onInputChange(e)
                                }/>
                        </div>

                        <div className="mb-3">
                            <label htmlFor="Title" className="form-label">
                                Employee title:
                            </label>
                            <input type={"text"}
                                className="form-control"
                                placeholder="Enter employee title"
                                name="title"
                                value={
                                    employeeData.title
                                }
                                onChange={
                                    (e) => onInputChange(e)
                                }/>
                        </div>

                        <div className="mb-3">
                            <label htmlFor="Location" className="form-label">
                                Employee location:
                            </label>
                            <input type={"text"}
                                className="form-control"
                                placeholder="Enter employee location"
                                name="location"
                                value={
                                    employeeData.location
                                }
                                onChange={
                                    (e) => onInputChange(e)
                                }/>
                        </div>

                        <div className="mb-3">
                            <label htmlFor="Picture" className="form-label">
                                Employee picture:
                            </label>
                            <input type="file"
                                // Change the input type to 'file'
                                className="form-control"
                                name="picture"
                                onChange={
                                    (e) => onFileInputChange(e)
                                }/>
                        </div>

                        <div className="mb-3">
                            <label htmlFor="DOB" className="form-label">
                                Employee DOB:
                            </label>
                            <input type={"date"}
                                className="form-control"
                                placeholder="Enter DOB"
                                name="DOB"
                                value={
                                    employeeData.DOB
                                }
                                onChange={
                                    (e) => onInputChange(e)
                                }/>
                        </div>

                        <button type="submit" className="btn btn-outline-primary">
                            Submit
                        </button>

                        <Link className="btn btn-outline-danger mx-2" to="/">
                            Cancel
                        </Link>
                    </form>
                </div>
            </div>
            <Modal show={showErrorModal}
                onHide={handleCloseErrorModal}
                centered>
                <Modal.Header closeButton>
                    <Modal.Title>Error</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <p style={
                        {color: "red"}
                    }>
                        {errorMessage}</p>
                </Modal.Body>
                <Modal.Footer>
                    <Button onClick={handleCloseErrorModal}>Close</Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
}
